Skill Test 2: Container Orchestration

Test Name - Task1 - Microservices with Nginx Ingress
Created by - Saleem Shaikh
Batch - 16A
Date - Aug 2nd 2026

