kubectl delete -f ingress.yaml

kubectl delete -f service1.yaml
kubectl delete -f service2.yaml
kubectl delete -f service3.yaml

kubectl delete -f deployment-service1.yaml
kubectl delete -f deployment-service2.yaml
kubectl delete -f deployment-service3.yaml

kubectl delete -f configmap-service1.yaml
kubectl delete -f configmap-service2.yaml
kubectl delete -f configmap-service3.yaml

kubectl delete -f namespace.yaml
