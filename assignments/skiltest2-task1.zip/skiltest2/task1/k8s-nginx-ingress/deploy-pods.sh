kubectl apply -f configmap-service1.yaml
kubectl apply -f configmap-service2.yaml
kubectl apply -f configmap-service3.yaml

kubectl apply -f deployment-service1.yaml
kubectl apply -f deployment-service2.yaml
kubectl apply -f deployment-service3.yaml

kubectl apply -f service1.yaml
kubectl apply -f service2.yaml
kubectl apply -f service3.yaml
