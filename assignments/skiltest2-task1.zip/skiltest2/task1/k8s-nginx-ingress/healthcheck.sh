#!/bin/bash

SERVICES=(
"http://service1.local.com"
"http://service2.local.com"
"http://service3.local.com"
)

for svc in "${SERVICES[@]}"
do
    STATUS=$(curl -o /dev/null -s -w "%{http_code}" "$svc")

    if [ "$STATUS" == "200" ]; then
        echo "$svc : Healthy"
    else
        echo "$svc : Unhealthy ($STATUS)"
    fi
done
