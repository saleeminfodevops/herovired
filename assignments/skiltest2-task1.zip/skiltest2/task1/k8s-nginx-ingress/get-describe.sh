kubectl describe pod <pod-name> -n microservices
