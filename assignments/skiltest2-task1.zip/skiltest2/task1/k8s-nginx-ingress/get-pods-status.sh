kubectl get pods -n skilltest2
kubectl get svc -n skilltest2
kubectl get ingresss -n skilltest2
kubectl get endpoints -n skilltest2
